# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'c827cfc81755bf022fcf2383f9f0d62c57f18cbae41a62c5545e32135e7d559414eb6fd2b7572664e3e30dd226260b2800742f7abf09ef28b722072bea6acfad'